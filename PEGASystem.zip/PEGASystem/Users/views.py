from django.contrib.auth import authenticate, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib import messages

#from login.models import students
# Create your views here.

def home(request):
    return render(request,"Users/login.html")


def cameras(request):
    return render(request,"Users/cameras.html")

def analytics(request):
    return render(request,"Users/analytics.html")
   
def logout_view(request):
    logout(request)
    return redirect('Users/login.html')