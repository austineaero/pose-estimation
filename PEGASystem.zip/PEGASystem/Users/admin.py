from django.contrib import admin
from . models import tbl_Authentication
# Register your models here.

admin.site.register(tbl_Authentication)
